#!/bin/sh

src=${TestGenIF}/src
working=${TestGenIF}/working
LIB="${TestGenIF}/lib"

while getopts "f:d:s:p:c:" option;
  do
  case $option in
      f)
      spec_file="$OPTARG";;
      d)
      maxdepth="$OPTARG";;
      s)
      strategy="$OPTARG";;
      p)
      suite="$OPTARG";;
      c)
      output="$OPTARG";;
  esac
done

rm -Rf $output
mkdir $output

results="./results_generation.txt"
rm -f "$results"

echo "_________________________________________________________________"
echo " TestGen-IF Tool: Test suite Generation"
echo "_________________________________________________________________"

ls "$suite" | while read purpose
  do
  echo
  echo "Test Purpose : $purpose"
  cp "$suite/$purpose" "$src/test_purpose.C"
  
  name="$(echo $purpose | cut -d"." -f1)"
  testcase="$output/tc_$name"
  
  cd $src
  echo "Compiling Test Purpose $purpose ..."
  ./compile-tp.sh 2>> /dev//null
  
  cd $working
  echo "Starting Test Generation for $purpose ..."
  ./testgenif -f $spec_file -d $maxdepth -s $strategy
  
  $LIB/filter-tp.sh output.sequence	
  cp "./final.sequence" $testcase
  
  echo "_________________________________________________________________" >> "$results"
  echo "Test Purpose $purpose:" >> "$results"
  cat "./output.stat" >> "$results"
  echo "_________________________________________________________________" >> "$results"
  echo " Test Sequence:" >> "$results"
  cat "./output.sequence" >> "$results"
  echo "_________________________________________________________________" >> "$results"
  echo "Filtered Test Sequence:" >> "$results"
  cat "./final.sequence" >> "$results"
done

echo
echo "   >>> Test cases directory : $output"
echo "   >>> Test generation results (test cases & statistics) : results_generation.txt"
echo "   >>> Thanks!"
echo
