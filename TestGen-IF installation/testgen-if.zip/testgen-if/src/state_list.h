/* 

state_list.h : a List of data.

Last modification by Mounir LALLALI mlallali@gmail.com
2/02/2009
   
Main file: mainExplorator.C
*/

#ifndef __STATE_LIST_HH__
#define __STATE_LIST_HH__

#include <stdlib.h>
#include <string>
#include <fstream>
#include <map>
#include <list>
#include <string.h>
#include "state_stack.h"
#include "simulator.h"

using namespace std;

struct stateNode {
  IfConfig* state;
  long int pos;
  long int depth;
  long int father;
  long int label_id;
} ;

class StateList{
 public:
  StateList();
  ~StateList();
  void clear();
  void put (IfConfig* s,long int depth, long int father,long int label_id);
  void put (stateNode p);
  void update (stateNode p);
  void remove_state(IfConfig* s);
  long int getPos(IfConfig* s);
  long int getFirstPos(); 
  long int getLastPos();
  long int getDepth(IfConfig* s);
  void setDepth(IfConfig* s,long int depth);
  bool getFather(IfConfig* s, stateNode& p);
  bool getFather(stateNode n, stateNode& p);
  void getNode(IfConfig* s, stateNode& p);
  stateNode getNode(long int pos,long int init);
  long int getFatherId(IfConfig* s);
  void printPath(IfConfig* s);
  void getPath(stateNode state_node); 
  void dump_list();
  long int getSize();
  IfConfig* get();
  bool isEmpty();
  void print_aldebaran_suite (long int source,long int label_id,long int target);
  
protected:
  ofstream output_suite;    
  
 private:
  list<stateNode> _state;
  long int pos_current;
  long int LocalDepth; // local depth (in a neighborhood)
};

#endif	// __STATE_LIST_HH__
