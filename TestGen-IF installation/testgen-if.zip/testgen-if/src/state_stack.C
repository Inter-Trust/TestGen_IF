/* 

  state_stack.C : a Stack of data.
  
  last update 02/02/2009 by Mounir Lallali mlallli@gmail.com
   
  Main file: mainExplorator.C
*/

#include "state_stack.h"

StateStack::StateStack()
{
  pos_current = 0; //current position starts with the initial one
}

StateStack::~StateStack()
{
}

void
StateStack::put(stateNode s)
{
  _state.push(s); 
}


long int StateStack::put(IfConfig *s,long int depth,long int father)
{
  stateNode p;
  p.state = s;
  p.pos = pos_current;
  p.depth = depth + 1;
  p.father = father;
  p.label_id = -1;
  _state.push(p);
  pos_current++;
  return p.pos; 
}

stateNode StateStack::get()
{
  stateNode q = _state.top();
  _state.pop();
  return q ;
}

bool StateStack::isEmpty()
{
  return _state.empty();
}

void StateStack::remove_state()
{
  _state.pop();
}

void StateStack::clear()
{
  while (!isEmpty())
    _state.pop();
}
