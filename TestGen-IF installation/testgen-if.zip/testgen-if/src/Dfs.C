/* 

Dfs.C : The search in depth first search

Last modification by Mounir LALLALI mlallali@gmail.com
03/04/2008 

Main file: mainExplorator.C
*/

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

#include <signal.h>
#include "mainExplorator.h"
#include "state_stack.h"
#include "simulator.h"


/************* DFS ****************/

DfsExplorator::DfsExplorator(const IfEngine* engine, char*  sc_file): Explorator(engine,sc_file) {
  readTestPurposes(sc_file);
  checkVariableSC(); //verifies the SC (Stop Conditions) (see the "mainExplorator.C" file)
  raiz = 0; //"raiz" is the root node.The first one to be searched (Recommended: "raiz =0").
};

/********** DFS::VISIT_ALL *****************/
void DfsExplorator::visitAll(int depthlim){
  
  int jump_counter = 0; /* it counts the number of total jumps done during the exploration */
  stateNode jump_node;
  
  IfConfig* start = m_engine->start();
  start -> setMark(REACHED); 
  m_stack.put(start, -1, -1);
  output_queue.put(start, -1, -1,NULL);
  
  while (! m_stack.isEmpty()) {
    state_node = m_stack.get();
    if (state_node.state != 0) {
      if (state_node.depth > (depthlim -1 + raiz)) {
	jump_counter++;
	printf(" >>>> a Jump from State at Depth %ld to State at Depth %ld - Depth Limit = %d  \n", raiz,state_node.depth,depthlim);
	printf("_________________________________________________________________\n");
	
	jump_node = random_jump();
	//output_queue.getPath(jump_node, seq);
	output_queue.update(jump_node);
	m_stack.clear();
	
	state_node.state = jump_node.state;
	state_node.pos = jump_node.pos;
	state_node.depth = jump_node.depth;      
	state_node.father = -1;
	raiz = jump_node.depth;
      }
      
      int hitDepth = visit(state_node.state,state_node.depth,state_node.pos);
      if (hitDepth != -1) {
	raiz = state_node.depth;
      }
      
      m_engine->run(state_node.state);
    }
  }
  
  printf(" Fail! - All the Stop Conditions are not Founded. \n");
  printf("_________________________________________________________________ \n");
  printf(" Number of Satisfied Conditions = %d/%d. \n", NFoundSC,NStopConditions);  
  printf(" DFS - Number of executed JUMPS = %d. \n",jump_counter);
  printf("_________________________________________________________________ \n\n");
  
}


long int DfsExplorator::visit (const IfConfig* state,long int depth,long int positionState) {
  FILE *f;
  
  if ((f = fopen("output.sta", "a"))!=NULL) {
    state->print(f); 
  }
  
  int hitDepth = checkStateSC(state,depth,positionState);
  return hitDepth;
}


void DfsExplorator::explore(IfConfig* source, IfLabel* label, IfConfig* target) {
  
  int lengthLabel;      /* lenght of the Label (how many atributtes does it has?)*/
  int  i=0;             /* temporary variable*/
  int kindSignal;       /* type of the signal in the Label transition: ex: 5=input: 6=output */
  char *c3;             /* it contains the "signal" in the Label transition */
  stateNode p;  
  int id_source;
  IfEvent *a1; //= label->getAt(i);// Using IfEvent variable
  long int depth;
  long int positionSource, positionTarget;
  
  if (!((target->getMark()) & REACHED)) {
    target->setMark(REACHED); 
    m_stack.put(target, state_node.depth, state_node.pos);    
    //output_queue.put(target, state_node.depth, state_node.pos,label);
    //print_aldebaran(state_node.pos, label, output_queue.getLastPos());
    
    depth = state_node.depth;
    positionSource = state_node.pos;
    positionTarget = output_queue.getLastPos();
    
  } else { 
    id_source = state_node.pos;
    output_queue.getNode(target,p);
    //print_aldebaran(id_source, label, p.pos);

    depth = state_node.depth;
    positionSource = id_source;
    positionTarget = p.pos;
  }
   	
  lengthLabel = label->getLength(); /* it identifies how many "signals" are in the transition*/

  while (i<lengthLabel) {
    a1 = label->getAt(i);//a1 if IfEvent type
    c3 = a1->getValue(); /* "signal/message" presented in the transition */
    kindSignal = a1->getKind(); /* type of the signal (input/output/other) of the transition */ 
    
    /***************** CHECKING STOP CONDITIONS *******************/
    int depth1 = checkSignalSC(kindSignal, c3, source, depth,positionSource,label,positionTarget); //see "ManageStopConditions.C"
    int depth2 = checkTimeSC(kindSignal, c3, source,depth,positionSource,label,positionTarget);   //see "ManageStopConditions.C"

    if (depth1 >=0) 
      raiz = depth1;
    
    if (depth2 >=0) 
      raiz = depth2;
    i++;
  } 
}
