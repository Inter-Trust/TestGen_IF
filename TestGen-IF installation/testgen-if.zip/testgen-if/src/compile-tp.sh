#!/bin/sh
make clean 2>> /dev//null 1>> /dev//null 
make tp 2>> /dev//null 1>> /dev//null
make install 2>> /dev//null 1>> /dev//null

