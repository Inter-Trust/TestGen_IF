#!/bin/sh
make clean
echo "make all"
make all
echo "make install"
make install

